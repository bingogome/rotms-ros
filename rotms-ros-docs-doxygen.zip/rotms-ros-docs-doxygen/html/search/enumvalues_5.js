var searchData=
[
  ['red_1028',['RED',['../d7/de8/namespaceprint__color__ros.html#a06f471e260a2bf60b6da2fe25bf9f460ae61f227e35f8a9d4de7e9e21fabccaaa',1,'print_color_ros']]]
];
