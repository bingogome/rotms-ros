var searchData=
[
  ['green_1026',['GREEN',['../d7/de8/namespaceprint__color__ros.html#a06f471e260a2bf60b6da2fe25bf9f460a9585bcfd9ee066f5e9de34be81535adf',1,'print_color_ros']]]
];
