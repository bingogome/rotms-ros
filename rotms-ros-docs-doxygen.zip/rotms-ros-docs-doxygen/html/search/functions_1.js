var searchData=
[
  ['bodyrefbodycallback_649',['BodyRefBodyCallBack',['../dc/db2/classMngrTBodyPtrtip.html#abb7d6669efdcfe1198a51d38fd24038f',1,'MngrTBodyPtrtip']]],
  ['bodyrefptrtipcallback_650',['BodyRefPtrtipCallBack',['../dc/db2/classMngrTBodyPtrtip.html#aefa866e5a87a02d05910c22abe7ddc5c',1,'MngrTBodyPtrtip']]]
];
