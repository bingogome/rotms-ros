var searchData=
[
  ['black_1022',['BLACK',['../d7/de8/namespaceprint__color__ros.html#a06f471e260a2bf60b6da2fe25bf9f460a9cc998073e8bfef5ae423cc38a7bcd98',1,'print_color_ros']]],
  ['blue_1023',['BLUE',['../d7/de8/namespaceprint__color__ros.html#a06f471e260a2bf60b6da2fe25bf9f460a34308b6c9d0f49668811228ebecd566f',1,'print_color_ros']]]
];
