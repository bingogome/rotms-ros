var searchData=
[
  ['yellow_497',['YELLOW',['../d7/de8/namespaceprint__color__ros.html#a06f471e260a2bf60b6da2fe25bf9f460a3eb2bd286f82bfcda87517d771082e9e',1,'print_color_ros']]]
];
