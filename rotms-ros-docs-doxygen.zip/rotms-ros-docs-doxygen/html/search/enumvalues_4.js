var searchData=
[
  ['magenta_1027',['MAGENTA',['../d7/de8/namespaceprint__color__ros.html#a06f471e260a2bf60b6da2fe25bf9f460a95d94c830d25e7d884804b0f50e1165f',1,'print_color_ros']]]
];
